## Ionic Boilerplate

**Important!**
- You will need to run `npm install` to install the dependencies from the package.json file before you can run the app.

- To run the application run `ionic serve`.