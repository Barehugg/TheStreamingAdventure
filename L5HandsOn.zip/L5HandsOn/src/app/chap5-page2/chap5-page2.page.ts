import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap5-page2',
  templateUrl: './chap5-page2.page.html',
  styleUrls: ['./chap5-page2.page.scss'],
})
export class Chap5Page2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
