import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap3-page2',
  templateUrl: './chap3-page2.page.html',
  styleUrls: ['./chap3-page2.page.scss'],
})
export class Chap3Page2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
