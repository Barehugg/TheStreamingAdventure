import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap1-page2',
  templateUrl: './chap1-page2.page.html',
  styleUrls: ['./chap1-page2.page.scss'],
})
export class Chap1Page2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
