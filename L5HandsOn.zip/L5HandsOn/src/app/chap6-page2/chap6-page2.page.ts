import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap6-page2',
  templateUrl: './chap6-page2.page.html',
  styleUrls: ['./chap6-page2.page.scss'],
})
export class Chap6Page2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
