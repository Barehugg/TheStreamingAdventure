import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap2-page2',
  templateUrl: './chap2-page2.page.html',
  styleUrls: ['./chap2-page2.page.scss'],
})
export class Chap2Page2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
