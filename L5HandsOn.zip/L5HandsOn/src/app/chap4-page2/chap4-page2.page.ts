import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap4-page2',
  templateUrl: './chap4-page2.page.html',
  styleUrls: ['./chap4-page2.page.scss'],
})
export class Chap4Page2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
